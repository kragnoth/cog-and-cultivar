# Architecture

How Cog & Cultivar is put together, and where new code goes. Gameplay design lives in [`design-spec.md`](design-spec.md).

## Layers

```
com.kragnoth.cultivar
├── Cultivar.java            common entry: config, registries, network, datagen, modules
├── api/                     public, stable-ish types (addons depend on these)
│   ├── CultivarRegistries   every registry key + static registry instance
│   ├── genetics/            Stat, AllelePair, Genome (data component)
│   ├── plant/               Plant, Product, Mutation, Weed, Fertilizer (datapack records)
│   ├── soil/                Soil, SoilLevels (humidity/acidity/nutrient scales)
│   ├── condition/           GrowthCondition + type registry (dispatch codec)
│   ├── modifier/            PlantModifier + type registry (dispatch codec)
│   └── influence/           CropInfluence, InfluenceEffects, InfluenceScaling (beehives, sprinklers, heaters)
├── core/                    framework; feature code never goes here
│   ├── module/              CultivarModule interface + CultivarModules index
│   ├── registry/            NeoForge registry wiring
│   ├── config/              server (gameplay) config
│   ├── network/             single versioned payload channel
│   ├── work/                ServerWorkQueue: time-sliced server jobs
│   └── datagen/             datagen entry + DataBootstraps collector
├── content/<feature>/       one package per feature module (core, trellis, irrigation, conservatory...)
├── compat/<modid>/          one package per integration (create, jei, jade...)
├── mixin/                   mixins (client ones under mixin/client)
├── gametest/                dedicated-server tests run in CI
└── client/                  client-only entry, ClientModule index, client config, renderers
```

## Modules

A feature is a `CultivarModule` (common) plus, optionally, a `ClientModule` (client). Each module:

- owns its `DeferredRegister`s (no shared mega-registry file, so PRs don't conflict);
- registers payloads through `registerPayloads` (already versioned);
- contributes datagen through `bootstrapData`;
- is listed once in `core/module/CultivarModules.ALL` (and `client/CultivarClient.MODULES` if it has client code).

Optional integrations implement `shouldLoad()` with `ModList.get().isLoaded(...)` and keep every class reference to the other mod out of the module class itself.

Cross-feature effects go through API hooks rather than imports. A module that changes a crop's
environment registers a `HumidityModifier`, `LightModifier` or `MoistureSource` with `CultivarEnvironment` in
`onConstruct`; a block that holds a plant implements `PlantHolder` and builds on `PlantCore`. Layering is checked
by `checkModuleBoundaries` (see `docs/EXTENSION_POINTS.md`).

## Data vs code

| Kind | Where | Changes need |
|---|---|---|
| Plants, soils, mutations, weeds, fertilizers, crop influences | Datapack registries (`data/<ns>/cultivar/<registry>/*.json`) | JSON only; modpacks can override |
| Stats, condition types, modifier types, influence scaling types | Static registries | Java; addons register with a `DeferredRegister` |
| Gameplay tuning | `serverconfig/cultivar-server.toml` (per world, synced) | Config |
| Visual preferences | `config/cultivar-client.toml` | Config |

Records gain new fields **only** as `optionalFieldOf(..., default)`, so existing JSON and saved items keep loading. Enum scales are append-only.

## Server safety rules

1. **Client code lives under `client/`.** `./gradlew check` runs `checkSidedness`, which fails the build if any other package imports `net.minecraft.client`, `com.mojang.blaze3d` or `net.neoforged.neoforge.client`.
2. **CI boots a real dedicated server** (`runGameTestServer`) on every PR. A leaked client class crashes it.
3. **Registries are identical on both sides.** Never skip registering a block or item based on config; disable behaviour with server config instead.
4. **One network channel, versioned.** Bump `CultivarNetwork.PROTOCOL_VERSION` on any payload change. Prefer block-entity sync and data components over custom packets.
5. **Server state is never trusted from the client.** Payload handlers validate distance, permissions and that the target block is loaded.

## Performance rules

- Crops grow on `randomTick`. No per-crop block-entity ticker.
- Anything that scans more than a handful of blocks goes through `ServerWorkQueue` (budget set in server config).
- Nearby-source lookups (beehives) use the POI index, not block scans, and are cached on the crop.
- Growth requirements are cached per crop and invalidated by neighbour or soil change.
- Client-only polish (particles, animations) never adds server work.

## Extending from an addon

Everything below is public API (`com.kragnoth.cultivar.api`) and needs no changes to this mod. The dropped
Phase 5 (temperature) is the worked example.

- **New growth condition** (e.g. temperature): register a `GrowthConditionType` in
  `CultivarRegistries.GROWTH_CONDITION_TYPE` with a `MapCodec` for your condition. `GrowthCondition.test` gets a
  `GrowthContext` (level, crop pos, soil) and the plant's Strength, so a temperature condition can read
  `level.getBiome(pos).value().getBaseTemperature()` and the height. Plants and mutations then use it from JSON
  (`{"type": "youraddon:temperature", ...}`) in `requirements` or mutation `conditions`. Return `true` from
  `isSoilProperty()` only if Hardy plants should ignore it.
- **New nearby source** (heaters, chillers, fans): `crop_influence` is a datapack registry, so a new source is a
  JSON file naming its blocks, radius and effects. If you need a new strength curve, register an
  `InfluenceScalingType`. For a brand-new kind of effect, use your own condition: it can scan for its source
  blocks around `GrowthContext.pos()`, since conditions run on the crop's random tick, which is cheap.
- **Soil containers**: implement `api.soil.SoilHost` on a block to hold a soil for the crop above it (the Planter
  Bed does this); crops resolve their soil and water through it. `isIdeal` (the Trial Bed) also lifts requirements,
  weeds and mutation habitats for the crop above.
- **New stats**: register a `Stat` in `CultivarRegistries.STAT`. Genomes carry any registered stat, and the
  breeding engine, assay cards, satchel dial and Create filters pick it up automatically.
- **Plants, soils, mutations, weeds, fertilizers**: datapack JSON only. See docs/PACKMAKERS.md.

## Tests

- `gametest/` holds dedicated-server game tests. Use the `cultivar:empty` template or add structure files under `data/cultivar/structure/`.
- Run locally with `./gradlew runGameTestServer`.

## Ponder scenes

Storyboards live in `client/ponder/CultivarScenes.java`; their structures in `assets/cultivar/ponder/*.nbt`
(`tools/ponder/gen_ponder_schematics.py`). Ponder reads text from lang keys `cultivar.ponder.<scene>.header` and
`.text_N`, numbered in the order texts are created, so after editing a scene run
`python3 tools/ponder/ponder_lang.py` (CI fails if the lang is stale). Keep each `.text("...")` a single literal.

## Alpha additions

- Modules add `/cultivar` subcommands through `CultivarModule.registerCommands`; the root is registered once in `Cultivar`.
- Per-tick crop behaviour is a `content.crop.tick.CropTickPhase`; see `docs/EXTENSION_POINTS.md`.
- Plot-style machines use `core.plot.PlotTracker`.
