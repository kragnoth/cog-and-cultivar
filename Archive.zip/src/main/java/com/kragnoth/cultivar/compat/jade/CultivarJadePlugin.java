package com.kragnoth.cultivar.compat.jade;

import com.kragnoth.cultivar.Cultivar;
import com.kragnoth.cultivar.content.crop.CropBlockEntity;
import com.kragnoth.cultivar.content.crop.CropInfo;
import com.kragnoth.cultivar.content.soil.Amendment;
import com.kragnoth.cultivar.content.soil.SoilAmendments;
import net.minecraft.world.level.block.Block;
import net.minecraft.network.chat.Component;
import java.util.List;
import com.kragnoth.cultivar.content.crop.TrellisBlock;
import net.minecraft.resources.ResourceLocation;
import snownee.jade.api.BlockAccessor;
import snownee.jade.api.IBlockComponentProvider;
import snownee.jade.api.ITooltip;
import snownee.jade.api.IWailaClientRegistration;
import snownee.jade.api.IWailaPlugin;
import snownee.jade.api.WailaPlugin;
import snownee.jade.api.config.IPluginConfig;

/**
 * Jade integration. Jade discovers this class by annotation and only loads it when Jade is installed,
 * so no module entry is needed. Crop data is already synced to clients, so this is client-only.
 */
@WailaPlugin(Cultivar.MOD_ID)
public final class CultivarJadePlugin implements IWailaPlugin {
    @Override
    public void registerClient(IWailaClientRegistration registration) {
        registration.registerBlockComponent(CropProvider.INSTANCE, TrellisBlock.class);
        registration.registerBlockComponent(CropProvider.INSTANCE, com.kragnoth.cultivar.content.field.FieldCropBlock.class);
        registration.registerBlockComponent(SoilProvider.INSTANCE, Block.class);
        registration.registerBlockComponent(OllaProvider.INSTANCE, com.kragnoth.cultivar.content.irrigation.OllaBlock.class);
    }

    /** Olla: filled or not, and how much farmland it keeps moist (the goggles readout minus the title Jade shows). */
    enum OllaProvider implements IBlockComponentProvider {
        INSTANCE;

        private static final ResourceLocation UID = Cultivar.id("olla");

        @Override
        public ResourceLocation getUid() {
            return UID;
        }

        @Override
        public void appendTooltip(ITooltip tooltip, BlockAccessor accessor, IPluginConfig config) {
            var lines = com.kragnoth.cultivar.content.irrigation.OllaBlock.readout(accessor.getLevel(), accessor.getPosition(), accessor.getBlockState());
            lines.subList(1, lines.size()).forEach(tooltip::add);
        }
    }

    /** Any soil block (or Planter Bed) a conditioner has been used on. */
    enum SoilProvider implements IBlockComponentProvider {
        INSTANCE;

        private static final ResourceLocation UID = Cultivar.id("soil_amendment");

        @Override
        public ResourceLocation getUid() {
            return UID;
        }

        @Override
        public void appendTooltip(ITooltip tooltip, BlockAccessor accessor, IPluginConfig config) {
            if (accessor.getBlock() instanceof TrellisBlock || accessor.getBlock() instanceof com.kragnoth.cultivar.content.field.FieldCropBlock) {
                return;
            }
            Amendment amendment = SoilAmendments.get(accessor.getLevel(), accessor.getPosition());
            if (!amendment.isEmpty()) {
                tooltip.add(SoilAmendments.describe(amendment));
            }
        }
    }

    enum CropProvider implements IBlockComponentProvider {
        INSTANCE;

        private static final ResourceLocation UID = Cultivar.id("crop");

        @Override
        public ResourceLocation getUid() {
            return UID;
        }

        @Override
        public void appendTooltip(ITooltip tooltip, BlockAccessor accessor, IPluginConfig config) {
            var fieldCrop = com.kragnoth.cultivar.content.field.FieldCropBlock.baseEntity(accessor.getLevel(), accessor.getPosition())
                    .filter(f -> accessor.getBlock() instanceof com.kragnoth.cultivar.content.field.FieldCropBlock && f.plant().hasPlant());
            if (fieldCrop.isPresent()) {
                var field = fieldCrop.get();
                CropInfo.lines(CropInfo.Subject.simple(field.plant(), accessor.getLevel(), field.getBlockPos(), field.getBlockState()),
                        CropInfo.Detail.BRIEF).forEach(tooltip::add);
                return;
            }
            if (!(CropBlockEntity.resolve(accessor.getLevel(), accessor.getPosition()).orElse(null) instanceof CropBlockEntity crop)) {
                return;
            }
            // Brief on purpose (name, what's wrong, why): the full readout lives in Create goggles.
            if (crop.hasPlant() || crop.isCross()) {
                CropInfo.lines(crop, CropInfo.Detail.BRIEF).forEach(tooltip::add);
            } else {
                Amendment amendment = SoilAmendments.get(accessor.getLevel(), crop.getBlockPos().below());
                if (!amendment.isEmpty()) {
                    tooltip.add(SoilAmendments.describe(amendment));
                }
                if (crop.weed() != null) {
                    tooltip.add(CropInfo.lines(crop).getLast()); // the blight line
                }
            }
        }
    }
}
