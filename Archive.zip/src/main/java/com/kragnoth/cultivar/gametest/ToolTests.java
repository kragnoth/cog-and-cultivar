package com.kragnoth.cultivar.gametest;

import com.kragnoth.cultivar.Cultivar;
import com.kragnoth.cultivar.api.CultivarRegistries;
import com.kragnoth.cultivar.api.genetics.AllelePair;
import com.kragnoth.cultivar.api.genetics.Genome;
import com.kragnoth.cultivar.api.plant.Plant;
import com.kragnoth.cultivar.content.core.CoreModule;
import com.kragnoth.cultivar.content.crop.CropBlockEntity;
import com.kragnoth.cultivar.content.crop.CropModule;
import com.kragnoth.cultivar.content.crop.CultivarSeedItem;
import com.kragnoth.cultivar.content.tools.SeedSatchelItem;
import com.kragnoth.cultivar.content.tools.ToolsModule;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

import java.util.Map;

@GameTestHolder(Cultivar.MOD_ID)
@PrefixGameTestTemplate(false)
public final class ToolTests {
    private ToolTests() {}

    private static Holder<Plant> wheat(GameTestHelper h) {
        return h.getLevel().registryAccess().registryOrThrow(CultivarRegistries.PLANT)
                .getHolderOrThrow(ResourceKey.create(CultivarRegistries.PLANT, ResourceLocation.withDefaultNamespace("wheat")));
    }

    @GameTest(template = "empty")
    public static void transplantKeepsStage(GameTestHelper h) {
        BlockPos a = new BlockPos(0, 1, 0), b = new BlockPos(2, 1, 0);
        h.setBlock(a.below(), Blocks.FARMLAND);
        h.setBlock(b.below(), Blocks.FARMLAND);
        h.setBlock(a, CropModule.TIMBER_TRELLIS.get());
        h.setBlock(b, CropModule.TIMBER_TRELLIS.get());
        CropBlockEntity from = (CropBlockEntity) h.getBlockEntity(a);
        CropBlockEntity to = (CropBlockEntity) h.getBlockEntity(b);
        from.plant(Genome.base(wheat(h)), 5);
        var lifted = from.uproot().orElseThrow();
        h.assertTrue(!from.hasPlant(), "source trellis is empty after uprooting");
        h.assertTrue(to.plant(lifted.genome(), lifted.stage()) && to.stage() == 5, "replanted at the same stage");
        h.succeed();
    }

    @GameTest(template = "empty")
    public static void satchelDialPicksBest(GameTestHelper h) {
        Holder<Plant> wheat = wheat(h);
        Genome weak = new Genome(wheat, Map.of(CoreModule.GROWTH.getKey(), AllelePair.of(2, 2)));
        Genome strong = new Genome(wheat, Map.of(CoreModule.GROWTH.getKey(), AllelePair.of(9, 9)));
        ItemStack satchel = new ItemStack(ToolsModule.SEED_SATCHEL.get());
        SeedSatchelItem.insert(satchel, CultivarSeedItem.of(weak, true).copyWithCount(3));
        SeedSatchelItem.insert(satchel, CultivarSeedItem.of(strong, true));
        satchel.set(ToolsModule.SATCHEL_DIAL.get(), new SeedSatchelItem.Dial(CoreModule.GROWTH.getKey()));
        Genome first = SeedSatchelItem.takeOne(satchel).orElseThrow().get(CoreModule.GENOME.get());
        h.assertTrue(first.equals(strong), "dial set to growth takes the growth-9 seed first");
        h.assertTrue(satchel.get(ToolsModule.SATCHEL_CONTENTS.get()).total() == 3, "three seeds remain");
        // Put the strong seed back: growth 2 is more than 2 below growth 9, so all three weak seeds are culls.
        SeedSatchelItem.insert(satchel, CultivarSeedItem.of(strong, true));
        // An unassayed seed is never culled, whatever its stats.
        SeedSatchelItem.insert(satchel, CultivarSeedItem.of(weak));
        int culled = 0;
        while (SeedSatchelItem.cullOne(satchel).isPresent()) culled++;
        h.assertTrue(culled == 3, "all three growth-2 seeds culled, got " + culled);
        h.assertTrue(satchel.get(ToolsModule.SATCHEL_CONTENTS.get()).total() == 2, "the keeper and the unassayed seed remain");
        h.succeed();
    }

    @GameTest(template = "empty")
    public static void shearsTakeClonesAndStrengthTenIsHardy(GameTestHelper h) {
        var plants = h.getLevel().registryAccess().registryOrThrow(com.kragnoth.cultivar.api.CultivarRegistries.PLANT);
        var wheat = plants.getHolderOrThrow(net.minecraft.resources.ResourceKey.create(com.kragnoth.cultivar.api.CultivarRegistries.PLANT,
                net.minecraft.resources.ResourceLocation.withDefaultNamespace("wheat")));
        BlockPos pos = new BlockPos(1, 2, 1);
        h.setBlock(pos.below(), net.minecraft.world.level.block.Blocks.FARMLAND);
        h.setBlock(pos, com.kragnoth.cultivar.content.crop.CropModule.TIMBER_TRELLIS.get());
        var crop = (com.kragnoth.cultivar.content.crop.CropBlockEntity) h.getBlockEntity(pos);
        Genome genome = Genome.base(wheat);
        crop.plant(genome, 3);
        java.util.List<ItemStack> drops = new java.util.ArrayList<>();
        int snips = 0;
        while (crop.clip(drops::add)) {
            snips++;
        }
        h.assertTrue(snips == 2 && crop.stage() == 1, "each snip costs a stage; no cuttings below stage 2");
        long cuttings = drops.stream().filter(s -> s.is(ToolsModule.CUTTING.get())).count();
        h.assertTrue(cuttings == 2 && drops.stream().filter(s -> s.is(ToolsModule.CUTTING.get()))
                .allMatch(s -> genome.equals(s.get(CoreModule.GENOME.get()))), "cuttings are exact clones");
        h.assertTrue(SeedSatchelItem.insert(new ItemStack(ToolsModule.SEED_SATCHEL.get()), drops.get(0)) == 0,
                "cuttings don't go in the satchel");
        h.assertTrue(com.kragnoth.cultivar.content.crop.TrellisBlock.genomeFor(drops.get(0), h.getLevel()).isEmpty(),
                "cuttings are not seeds (no planting bypass, not accepted by beds)");

        h.assertTrue(!crop.isHardy() && crop.requirements().size() == wheat.value().requirements().size(), "base wheat is not hardy");
        var strength = CoreModule.STRENGTH.getKey();
        var stats = new java.util.HashMap<>(genome.stats());
        stats.put(strength, new com.kragnoth.cultivar.api.genetics.AllelePair(10, 10));
        crop.uproot();
        crop.plant(new Genome(wheat, stats), 0);
        h.assertTrue(crop.isHardy() && crop.requirements().stream().noneMatch(c -> c.isSoilProperty()),
                "strength 10 drops the soil-property requirements");
        h.assertTrue(com.kragnoth.cultivar.content.tools.CuttingItem.takeChance(new Genome(wheat, stats)) == 1.0, "strong cuttings always take");
        h.succeed();
    }

    @GameTest(template = "empty")
    public static void satchelHarvestsSeedsByVigour(GameTestHelper h) {
        var wheat = h.getLevel().registryAccess().registryOrThrow(com.kragnoth.cultivar.api.CultivarRegistries.PLANT)
                .getHolderOrThrow(net.minecraft.resources.ResourceKey.create(com.kragnoth.cultivar.api.CultivarRegistries.PLANT,
                        net.minecraft.resources.ResourceLocation.withDefaultNamespace("wheat")));
        BlockPos pos = new BlockPos(1, 2, 1);
        h.setBlock(pos.below(), net.minecraft.world.level.block.Blocks.FARMLAND);
        h.setBlock(pos, com.kragnoth.cultivar.content.crop.CropModule.TIMBER_TRELLIS.get());
        var crop = (com.kragnoth.cultivar.content.crop.CropBlockEntity) h.getBlockEntity(pos);
        var stats = new java.util.HashMap<>(Genome.base(wheat).stats());
        stats.put(CoreModule.VIGOUR.getKey(), new com.kragnoth.cultivar.api.genetics.AllelePair(10, 10));
        Genome strong = new Genome(wheat, stats);
        h.assertTrue(Math.abs(SeedSatchelItem.seedChance(strong) - 0.75) < 1e-9, "vigour 10 gives 75%");
        h.assertTrue(Math.abs(SeedSatchelItem.seedChance(Genome.base(wheat)) - 0.30) < 1e-9, "vigour 1 gives 30%");

        ItemStack satchel = new ItemStack(ToolsModule.SEED_SATCHEL.get());
        var random = net.minecraft.util.RandomSource.create(5L);
        int seeds = 0, produce = 0;
        java.util.List<ItemStack> drops = new java.util.ArrayList<>();
        for (int i = 0; i < 400; i++) {
            crop.uproot();
            crop.plant(strong, wheat.value().matureStage());
            if (SeedSatchelItem.gatherSeeds(crop, random, drops::add, s -> s.copyWithCount(s.getCount() - SeedSatchelItem.insert(satchel, s)))) {
                seeds++;
            }
            h.assertTrue(!crop.isMature(), "a satchel harvest resets the plant like any harvest");
        }
        produce = drops.stream().filter(s -> s.is(net.minecraft.world.item.Items.WHEAT)).mapToInt(ItemStack::getCount).sum();
        h.assertTrue(seeds > 260 && seeds < 340, "about 75% of harvests give a seed, got " + seeds);
        h.assertTrue(produce > 0, "produce still drops");
        h.assertTrue(satchel.get(ToolsModule.SATCHEL_CONTENTS.get()).total() == Math.min(seeds, SeedSatchelItem.CAPACITY),
                "seeds go into the satchel until it's full");
        h.succeed();
    }

    @GameTest(template = "empty")
    public static void satchelScreenActions(GameTestHelper h) {
        var wheat = h.getLevel().registryAccess().registryOrThrow(com.kragnoth.cultivar.api.CultivarRegistries.PLANT)
                .getHolderOrThrow(net.minecraft.resources.ResourceKey.create(com.kragnoth.cultivar.api.CultivarRegistries.PLANT,
                        net.minecraft.resources.ResourceLocation.withDefaultNamespace("wheat")));
        var stats = new java.util.HashMap<>(Genome.base(wheat).stats());
        stats.put(CoreModule.GAIN.getKey(), new com.kragnoth.cultivar.api.genetics.AllelePair(4, 4));
        Genome good = new Genome(wheat, stats);
        ItemStack satchel = new ItemStack(ToolsModule.SEED_SATCHEL.get());
        satchel.set(ToolsModule.SATCHEL_CONTENTS.get(), new SeedSatchelItem.Contents(java.util.List.of(
                new SeedSatchelItem.Entry(good, 3, true),
                new SeedSatchelItem.Entry(Genome.base(wheat), 5, false),
                new SeedSatchelItem.Entry(Genome.base(wheat), 2, true))));
        var player = net.neoforged.neoforge.common.util.FakePlayerFactory.get(h.getLevel(),
                new com.mojang.authlib.GameProfile(java.util.UUID.nameUUIDFromBytes("cultivar-satchel".getBytes()), "cultivar_satchel"));
        player.getInventory().clearContent();
        player.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND, satchel);
        var main = net.minecraft.world.InteractionHand.MAIN_HAND;

        SeedSatchelItem.apply(player, new com.kragnoth.cultivar.content.tools.SatchelActionPayload(main, 0,
                com.kragnoth.cultivar.content.tools.SatchelActionPayload.Action.TAKE));
        ItemStack held = player.getItemInHand(main);
        int taken = 0;
        for (ItemStack st : player.getInventory().items) {
            if (st.is(com.kragnoth.cultivar.content.crop.CropModule.SEED.get())) taken += st.getCount();
        }
        h.assertTrue(taken == 3, "Take moves that row's seeds into the inventory, got " + taken);
        h.assertTrue(SeedSatchelItem.entries(held).size() == 2, "the taken row is gone");

        SeedSatchelItem.apply(player, new com.kragnoth.cultivar.content.tools.SatchelActionPayload(main, 0,
                com.kragnoth.cultivar.content.tools.SatchelActionPayload.Action.VOID_UNASSAYED));
        h.assertTrue(SeedSatchelItem.entries(held).size() == 1 && SeedSatchelItem.entries(held).getFirst().assayed(),
                "Void unassayed keeps only assayed rows");
        SeedSatchelItem.apply(player, new com.kragnoth.cultivar.content.tools.SatchelActionPayload(main, 0,
                com.kragnoth.cultivar.content.tools.SatchelActionPayload.Action.VOID));
        h.assertTrue(SeedSatchelItem.entries(held).isEmpty(), "Void removes the row");
        SeedSatchelItem.apply(player, new com.kragnoth.cultivar.content.tools.SatchelActionPayload(main, 9,
                com.kragnoth.cultivar.content.tools.SatchelActionPayload.Action.VOID));
        SeedSatchelItem.apply(player, new com.kragnoth.cultivar.content.tools.SatchelActionPayload(main, 0,
                com.kragnoth.cultivar.content.tools.SatchelActionPayload.Action.TOGGLE_COLLECT));
        h.assertTrue(held.has(ToolsModule.SATCHEL_NO_COLLECT.get()), "the toggle turns auto-collect off");
        h.succeed();
    }

    @GameTest(template = "empty")
    public static void cropStatsNeedAnAssayedSeed(GameTestHelper h) {
        var wheat = h.getLevel().registryAccess().registryOrThrow(com.kragnoth.cultivar.api.CultivarRegistries.PLANT)
                .getHolderOrThrow(net.minecraft.resources.ResourceKey.create(com.kragnoth.cultivar.api.CultivarRegistries.PLANT,
                        net.minecraft.resources.ResourceLocation.withDefaultNamespace("wheat")));
        BlockPos pos = new BlockPos(1, 2, 1);
        h.setBlock(pos.below(), net.minecraft.world.level.block.Blocks.FARMLAND);
        h.setBlock(pos, com.kragnoth.cultivar.content.crop.CropModule.TIMBER_TRELLIS.get());
        var crop = (com.kragnoth.cultivar.content.crop.CropBlockEntity) h.getBlockEntity(pos);
        ItemStack plain = com.kragnoth.cultivar.content.crop.CultivarSeedItem.of(Genome.base(wheat));
        ItemStack read = com.kragnoth.cultivar.content.crop.CultivarSeedItem.of(Genome.base(wheat), true);
        String statName = net.minecraft.network.chat.Component.translatable("stat.cultivar.gain").getString();
        java.util.function.Predicate<com.kragnoth.cultivar.content.crop.CropBlockEntity> showsStats = c ->
                com.kragnoth.cultivar.content.crop.CropInfo.lines(c).stream().anyMatch(l -> l.getString().contains(statName));

        crop.plant(Genome.base(wheat), plain);
        h.assertTrue(!crop.statsKnown() && !showsStats.test(crop), "an unassayed seed's crop hides its stats");
        java.util.List<ItemStack> drops = new java.util.ArrayList<>();
        crop.collectBreakDrops(drops::add);
        h.assertTrue(!drops.getFirst().has(CoreModule.ASSAYED.get()), "its seed drops unassayed");

        crop.uproot();
        crop.plant(Genome.base(wheat), read);
        h.assertTrue(crop.statsKnown() && showsStats.test(crop), "an assayed seed's crop shows its stats");
        drops.clear();
        crop.collectBreakDrops(drops::add);
        h.assertTrue(drops.getFirst().has(CoreModule.ASSAYED.get()), "a known crop's seed stays assayed");
        h.succeed();
    }
}
